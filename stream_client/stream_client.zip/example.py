import pygatt
import time
import logging
import binascii

#logging.basicConfig()
#logging.getLogger('pygatt').setLevel(logging.DEBUG)

# The BGAPI backend will attempt to auto-discover the serial device name of the
# attached BGAPI-compatible USB adapter.
adapter = pygatt.BGAPIBackend()

try:
    adapter.start()
    scanned = adapter.scan(timeout=2)
    found_targets = [peripheral for peripheral in scanned if peripheral['name'] == 'Fake Ganglion' ]
    device = adapter.connect(found_targets[0]['address'], interval_min=6, interval_max=6)
    discovered_chars = device.discover_characteristics()
    print(discovered_chars)
    count = 0
    #start = time.time()
    #for _ in range(100):
    while True:
        packet = device.char_read('00008881-0000-1000-8000-00805f9b34fb')
        chan1 = int.from_bytes(packet[:3], byteorder='little', signed = True)
        print(chan1 * 0.001869917138805)
        #print(f"{count}: {binascii.hexlify(bytearray(device.char_read('00008881-0000-1000-8000-00805f9b34fb')))}")
        #count += 1
        #device.char_read('00008881-0000-1000-8000-00805f9b34fb')
        #time.sleep(1)
    #end = time.time()
    #print(end - start)

finally:
    adapter.stop()