import pygatt
import time
import logging
import binascii
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np

#logging.basicConfig()
#logging.getLogger('pygatt').setLevel(logging.DEBUG)



adapter = pygatt.BGAPIBackend()

try:
    adapter.start()
    scanned = adapter.scan(timeout=2)
    found_targets = [peripheral for peripheral in scanned if peripheral['name'] == 'Fake Ganglion' ]
    device = adapter.connect(found_targets[0]['address'], interval_min=6, interval_max=8)
    discovered_chars = device.discover_characteristics()
    print(discovered_chars)
except KeyboardInterrupt:
    adapter.stop()

# Parameters
x_len = 400        # Number of points to display
y_range = [-16000, 16000]  # Range of possible Y values to display

# Create figure for plotting
fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)
xs = list(range(0, 400))
ys = [0] * x_len
ax.set_ylim(y_range)

# Create a blank line. We will update the line in animate
line, = ax.plot(xs, ys)

# Add labels
plt.title('Data Stream')
plt.xlabel('Samples')
plt.ylabel('ADC Code')

# This function is called periodically from FuncAnimation
def animate(i, ys):

    # Read temperature (Celsius) from TMP102
    packet = device.char_read('00008881-0000-1000-8000-00805f9b34fb')
    chan1_1 = int.from_bytes(packet[:3], byteorder='little', signed=True)
    chan1_2 = int.from_bytes(packet[6:9], byteorder='little', signed=True)
    chan1_3 = int.from_bytes(packet[12:15], byteorder='little', signed=True)
    temp_c = round(chan1_1, 2)
    temp_f=(temp_c*9/5)+32

    # Add y to list
    ys.append(chan1_1*0.001869917138805)
    ys.append(chan1_2*0.001869917138805)
    ys.append(chan1_3*0.001869917138805)

    # Limit y list to set number of items
    ys = ys[-x_len:]

    # Update line with new Y values
    line.set_ydata(ys)

    return line,

# Set up plot to call animate() function periodically
ani = animation.FuncAnimation(fig,
    animate,
    fargs=(ys,),
    interval=1,
    blit=True)
plt.show()
